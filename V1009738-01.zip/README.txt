.Net Connector Server 12.2.1.3.0 - October 12, 2017

The Connector Server is for use with Identity Connectors only.
Connector server version 12.2.1.3.0 is backward compatible with earlier versions of the Connector server and therefore can be used for all existing ICF Connectors.


***********************************************************************************************************************************************************************************************************
NOTE: This connector server is compatible with older OIM versions as well.

***********************************************************************************************************************************************************************************************************



***********************************************************************************************************************************************************************************************************

NOTE:  Certificate Service (CS) installed on AD target must be with SHA2 algrithm
____________________________________________________________________________________

Certificate Service (CS) installed on AD target must be installed using SHA2 algorithm.
If CS is not with SHA2, then please do the same prior to switching to connector server upgrade.
Once CS is with SHA2 algorithm, customer needs to re-generate the certificate from connector server box which will go to OIM trust store and Connector server certificate store.

***********************************************************************************************************************************************************************************************************




***********************************************************************************************************************************************************************************************************

NOTE:  After upgrade customer can choose TLS1.2 protocol for secure communication between OIM and connector server
____________________________________________________________________________________________________________________

After upgrade of connector server, customer can choose the protocol for secure communication between OIM and connector server.
Supported protocols are TLS1, TLS1.1 and TLS1.2.

***********************************************************************************************************************************************************************************************************




***********************************************************************************************************************************************************************************************************

NOTE:  For installation of this connector server pack, please refer the product install guide.


***********************************************************************************************************************************************************************************************************



INSTRUCTIONS TO UPGRADE THE EXISTING .NET CONNECTOR SERVER
******************************************************

- Stop the connector server service.
- Typically, windows connector server is installed at "C:\Program Files (x86)\Identity Connectors\Connector Server" location. 
- Take a backup of installed Connector server directory i.e. C:\Program Files (x86)\Identity Connectors\Connector Server or If you have connector server installed at any custom location then take backup of the same.
- Use "ServiceInstall-1.5.0.0.msi" file shipped in latest connector server bundle to install the latest binaries at existing connector server location only.
i.e. C:\Program Files (x86)\Identity Connectors\Connector Server or If you have connector server installed at any custom location then choose the same.
- Open "ConnectorServer.exe.config" file from both locations i.e. installed location and backup location. 
  Update the below properties of "ConnectorServer.exe.config" file at installed location from "ConnectorServer.exe.config" file at backup location i.e.
        <add key="connectorserver.port" value="8759" />
        <add key="connectorserver.usessl" value="false" />
        <add key="connectorserver.certificatestorename" value="ConnectorServerSSLCertificate" />
        <add key="connectorserver.ifaddress" value="0.0.0.0" />
        <add key="logging.proxy" value="false"/>
Note: If CS is moved to SHA2, then re-generated certificate must be added to the connector server certificate store i.e. ConnectorServerSSLCertificate
- Set the key again for the newly installed connector server using the existing key value only.
        cd C:\Program Files (x86)\Identity Connectors\Connector Server
	ConnectorServer.exe /setKey <Existing_key>
- In newly installed connector server, we are providing an option to select the protocol for SSL comunication. OOTB it is TLS1.0.
  But customer can choose the between TLS1.0, TLS1.1 and TLS1.2. 
<!--Possible protocol values are Tls, Tls11, TLS12 -->
        <add key="connectorserver.protocol" value="Tls"/>
- We are not preserving any customizations during upgrade of connector server and it is a manual upgrade. 
If customer is having any other customization in any of the file, then re-do the same from the back-up location.
- Start the connector server after doing all the required settings.


